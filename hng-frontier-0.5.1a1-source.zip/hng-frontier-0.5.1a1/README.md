# HNG Frontier Memory 0.5.0a1

**Status: breakthrough-candidate research alpha.**

HNG Frontier is a model-external memory/control substrate for systems whose semantic state can be represented as HDC/VSA hypervectors. Version 0.5 combines three research tracks:

1. **assistant transition memory** — deterministic turn continuity, cross-chat episodic recall, state/action/outcome evidence and action gating;
2. **HDC document memory** — hierarchical semantic document state and coverage-oriented synopsis without an LLM in the summarization loop.
3. **perspective-conditioned memory** — explicit user/tenant scope, role/authority eligibility, and native HDC perspective/expertise/priority heads so identical semantic queries can route differently for different people.

The application owns semantics. HNG does not parse language, call an embedding service, or call an LLM. Your HDC interpreter supplies native semantic heads.

## Assistant memory

```text
turn t
  |
  +-- exact working state + prior next_state HV
  |
  +-- HDC interpreter
  |      state / goal / entity / sequence / action / outcome
  |
  +-- HNG historical transition recall
  |      approximate routing -> exact full-HV evidence
  |
  +-- MemoryFrame v1
         support | challenge | conflicted | insufficient_evidence
```

Key APIs:

```python
from hngfrontier import AssistantMemory

memory = AssistantMemory("./assistant-memory", hv_dim=10_000, space_id="my-hdc-v1")
ctx = memory.integration_context(conversation_id)
frame = memory.prepare_context(query_heads, conversation_id=conversation_id)
actions = memory.recommend_actions(query_heads, conversation_id=conversation_id)
gate = memory.evaluate_action(query_heads, proposed_action_hv, conversation_id=conversation_id)
memory.record_transition(...)
```

## Perspective-conditioned assistance

The same semantic problem can require a different answer for an IC, staff engineer, manager, or executive. HNG 0.5 treats that as a memory-addressing problem rather than asking the query text to carry all user context.

```python
from hngfrontier import PerspectiveProfile, PerspectiveOverride

memory.set_user_profile(PerspectiveProfile(
    user_id="alex", tenant_id="acme", role="individual-contributor",
    authority_level=1, abstraction_level=1,
    expertise={"backend": .9}, priorities=("reliability",),
))
memory.activate_perspective(conversation_id, "alex")
ctx = memory.integration_context(conversation_id)
# ctx.perspective is supplied to the HDC semantic adapter on every turn.
```

Perspective is deliberately split into three layers: exact private/tenant/global access boundaries; role/authority/abstraction eligibility; and optional `perspective`, `expertise`, and `priority` HDC heads for exact semantic evidence matching. See [`PERSPECTIVE_MEMORY.md`](PERSPECTIVE_MEMORY.md).

### Perspective gauntlet

On 64 identical semantic contexts across eight personas and an 8,192-action HDC library:

| Method | Exact action top-1 | Perspective violation |
|---|---:|---:|
| Raw HDC action router | 6.25% | n/a |
| HNG semantics only | 12.5% | 75% |
| HNG role/authority gating only (128-query sample) | 50% | 0% actor-role leakage by construction |
| HNG soft perspective HDC heads (128-query sample) | 100% | policy disabled |
| **HNG full perspective conditioning** | **100%** | **0%** |

The same durable user also switched into an acting role correctly on 64/64 queries; private-memory leakage was 0/2 adversarial checks; and a durable priority update changed future routing without rewriting history. These are synthetic HDC results, not a public personalization benchmark.

## Document memory

```text
long document
    |
    v
application HDC interpreter
    |
    +-- topic
    +-- claim
    +-- entity
    +-- evidence
    +-- role
    |
    v
HDCDocumentMemory
    |
    +-- HDC semantic-boundary discovery
    +-- segment prototypes
    +-- document prototypes
    +-- rare/exception role recall
    +-- bounded source evidence
    |
    v
DocumentSummaryFrame
    |
    +-- to_hdc_context()     # native HDC assistant
    +-- to_context_text()    # optional LLM/human rendering
```

```python
from hngfrontier import HDCDocumentMemory, CallableDocumentAdapter, DocumentUnitEncoding

with HDCDocumentMemory("./docs", hv_dim=10_000, space_id="my-doc-hdc-v1") as docs:
    docs.ingest(document_id, units, my_hdc_document_adapter)
    synopsis = docs.summarize_document(document_id, discover_structure=True)

    native_context = synopsis.to_hdc_context()   # no generated language
    evidence_text = synopsis.to_context_text()   # extractive provenance view
```

See [`DOCUMENT_MEMORY.md`](DOCUMENT_MEMORY.md).

## Current synthetic evidence

### Assistant ablation

128 HDC contexts, 4,096-action library (16 close variants/family):

- raw HDC exact-action top-1: **7.81%**;
- HNG outcome-grounded action top-1: **100%**;
- ambiguous current-turn-only episode recall: **0.78%**;
- HNG carried-state episode recall: **100%**.

The larger 0.3.1 gauntlet additionally covered 10,240 historical chats, 16,384 actions, changed-world sequence shifts, action evidence gating, 15% bit noise and a 20,000-turn conversation.

### Document synopsis

32 synthetic long documents / 8,960 HDC units / 40-unit synopsis budget:

| Method | Theme coverage | Key claims | Rare/priority evidence | Contradictions | Median |
|---|---:|---:|---:|---:|---:|
| **HNG HDC synopsis** | **100%** | **98.0%** | **100%** | **100%** | ~23.6 ms |
| lead-40 | 19.1% | 19.1% | 18.4% | 13.0% | ~0.005 ms |
| uniform-40 | **100%** | 23.0% | 17.4% | 11.5% | ~0.07 ms |
| flat semantic top-k | 21.7% | 21.7% | 14.2% | 15.6% | ~0.10 ms |
| importance top-k | 44.1% | 25.0% | 63.7% | 65.1% | ~0.05 ms |
| MMR | 100% | 57.2% | 99.0% | 100% | ~1.40 ms |
| oracle KMeans (`k=16`) | 100% | 100% | 100% | 100% | ~57.5 ms |

HNG inferred the semantic region count/order from HDC continuity (boundary F1 **1.00**); KMeans was given the oracle number of regions.

An 8,960-unit single document with 128 semantic themes was reduced to a 140-unit evidence frame with **100% theme, key-claim and priority-evidence coverage** in ~440 ms.

Targeted two-head document retrieval stayed at **100% recall@5 through 15% synthetic query-bit corruption** in the sampled workload.

These are synthetic semantic-geometry results. They are not claims of state-of-the-art natural-language summarization.

## Research position

HNG is **not** claiming invention of RAG, HDC/VSA associative memory, hierarchical retrieval, multi-vector search, or external agent memory. The breakthrough candidate is the combined architecture: native semantic state as persistent memory address, deterministic state continuity, conjunctive exact evidence, state/action/outcome history, and HDC-native hierarchical document context where language generation is optional.

Closest relevant directions include RAPTOR and GraphRAG for hierarchical/global document retrieval, and modern long-term agent-memory benchmarks such as LongMemEval-V2. The decisive next phase is public/real data: real interpreter traces, LongMemEval-V2, BillSum/GovReport, and matched-recall ANN comparisons.

See [`BREAKTHROUGH_REPORT.md`](BREAKTHROUGH_REPORT.md) and [`PUBLICATION_PLAN.md`](PUBLICATION_PLAN.md).

## Tests

```bash
python -m pip install -e ".[dev]"
python -m pytest -q
```

Current package suite: **30/30 green**.

## Public benchmark protocol

The release includes [`PUBLIC_BENCHMARKS.md`](PUBLIC_BENCHMARKS.md) and `benchmarks/qmsum_public_hdc.py` for an external human-data gate. The QMSum harness is included but **no QMSum score is claimed from this build environment** because the official dataset could not be materialized locally. See [`RESEARCH_STATUS.md`](RESEARCH_STATUS.md) for the precise publication/novelty status.
